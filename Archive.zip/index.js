require("dotenv").config();

const cron = require("node-cron");
const crypto = require("crypto");
const mysql = require("mysql2/promise");
const nodemailer = require("nodemailer");

const {
  GeneralMailTemplate,
} = require("./templates/email/GeneralMailTemplate");

const { TaskMailTemplate } = require("./templates/email/TaskEmailTemplate");

// ─────────────────────────────────────────────
// Expo Push Notification helper
// ─────────────────────────────────────────────

async function sendExpoPushNotifications(conn, userId, title, body, data = {}) {
  try {
    const [devices] = await conn.execute(
      "SELECT push_token FROM user_devices WHERE user_id = ? AND push_token IS NOT NULL AND push_token != ''",
      [userId],
    ).catch(() => [[]]);

    if (!devices.length) return;

    const messages = devices.map((d) => ({
      to: d.push_token,
      sound: "default",
      title,
      body,
      data,
    }));

    const response = await fetch("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify(messages),
    });

    if (!response.ok) {
      console.warn(`[ExpoPush] HTTP ${response.status} for user ${userId}`);
      return;
    }

    // Expo returns one receipt per message, in the same order as `messages`.
    // A token whose device uninstalled the app (or reinstalled, invalidating
    // it) comes back "DeviceNotRegistered" forever — without pruning it here,
    // every future cron tick keeps re-sending to (and re-logging warnings
    // for) a token Expo will never deliver to again.
    const body = await response.json().catch(() => null);
    const receipts = Array.isArray(body?.data) ? body.data : [];

    const deadTokens = receipts
      .map((receipt, i) =>
        receipt?.status === "error" && receipt?.details?.error === "DeviceNotRegistered"
          ? devices[i]?.push_token
          : null,
      )
      .filter(Boolean);

    if (deadTokens.length) {
      await conn.query(
        `DELETE FROM user_devices WHERE push_token IN (${deadTokens.map(() => "?").join(",")})`,
        deadTokens,
      ).catch((err) => {
        console.warn(`[ExpoPush] Failed to prune dead tokens:`, err.message);
      });
    }
  } catch (err) {
    console.warn(`[ExpoPush] Failed for user ${userId}:`, err.message);
  }
}

const DEFAULT_CRON_SCHEDULE = "* * * * *"; // every minute default
const DEFAULT_CLIENT_DB_PREFIX = "saleserp_";

function getLocalIsoString(dateObj = new Date()) {
  const tz = runtimeState.activeTimezone || "UTC";
  try {
    const formatter = new Intl.DateTimeFormat("sv-SE", {
      timeZone: tz,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
      timeZoneName: "longOffset",
    });
    const parts = formatter.formatToParts(dateObj);
    const get = (type) => parts.find((p) => p.type === type)?.value;

    let offset = get("timeZoneName");
    if (!offset || offset === "GMT") {
      offset = "Z";
    } else if (offset.startsWith("GMT")) {
      offset = offset.replace("GMT", ""); // e.g., converts 'GMT+05:30' to '+05:30'
    } else {
      offset = "Z";
    }

    return `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}:${get("second")}${offset}`;
  } catch (e) {
    return dateObj.toISOString();
  }
}

function formatDbDate(date) {
  const d = new Date(date);
  if (isNaN(d.getTime())) return null;
  return getLocalIsoString(d).slice(0, 19).replace("T", " ");
}
const DEFAULT_MAX_PARALLEL_CLIENTS = 3;
const SCHEDULE_REFRESH_INTERVAL_MS = 30000;
const MAX_HISTORY = 50;
// Key names are unchanged from when this schedule only drove recurring-invoice
// processing — the daemon now uses the SAME schedule/timezone/max-parallel
// settings to drive deal task reminders, overdue/due-today notifications, and
// document-expiry checks instead. Renaming the master_settings keys would
// require a data migration, so the names stay as-is; only the admin-facing
// label was generalized (see CronScheduleSettings.jsx).
const MASTER_SETTING_CRON_SCHEDULE = "recurring_invoice_cron_schedule";
const MASTER_SETTING_CRON_TIMEZONE = "recurring_invoice_cron_timezone";
const MASTER_SETTING_MAX_PARALLEL_CLIENTS =
  "recurring_invoice_max_parallel_clients";

const runtimeState = {
  runInProgress: false,
  activeSchedule: null,
  activeTimezone: null,
  activeCronTask: null,
  scheduleRefreshInFlight: false,
};

const clientPools = new Map();

// ─────────────────────────────────────────────
// Utility helpers
// ─────────────────────────────────────────────

function requiredEnv(name) {
  const value = process.env[name];
  if (!value || !String(value).trim()) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return String(value).trim();
}

function toPositiveInt(value, fallback) {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function sanitizeSubdomain(subdomain) {
  return String(subdomain || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "");
}

function normalizeMaybeJson(value, fallback, schemaCheck = null) {
  if (value == null || value === "") return fallback;
  if (typeof value !== "string") {
    if (schemaCheck && !schemaCheck(value)) return fallback;
    return value;
  }
  try {
    const parsed = JSON.parse(value);
    if (schemaCheck && !schemaCheck(parsed)) {
      console.warn("JSON schema check failed for value, using fallback");
      return fallback;
    }
    return parsed;
  } catch (err) {
    console.error("JSON parsing failed:", err.message);
    return fallback;
  }
}

function isTruthy(value) {
  return (
    value === true ||
    value === 1 ||
    value === "1" ||
    String(value || "").toLowerCase() === "true"
  );
}

function parseJsonArraySafe(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  if (typeof value !== "string") return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function getDealOwnerUserId(deal) {
  const history = parseJsonArraySafe(deal?.assigned_to)
    .map((item) => Number(item))
    .filter((item) => Number.isFinite(item));
  if (history.length) return history[history.length - 1];

  const createdBy = Number(deal?.created_by);
  return Number.isFinite(createdBy) ? createdBy : null;
}

// Same "last assigned_to element, else created_by" ownership resolution as
// getDealOwnerUserId, generalized for any table with that same convention
// (customer/supplier included) — the doc-expiry job notifies this owner.
function getRecordOwnerUserId(row) {
  const history = parseJsonArraySafe(row?.assigned_to)
    .map((item) => Number(item))
    .filter((item) => Number.isFinite(item));
  if (history.length) return history[history.length - 1];

  const createdBy = Number(row?.created_by);
  return Number.isFinite(createdBy) ? createdBy : null;
}

function slugifyDocName(name) {
  return String(name || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "doc";
}

async function upsertNotification(conn, payload) {
  const {
    type,
    category = "deals",
    entityType,
    entityId,
    parentEntityType = null,
    parentEntityId = null,
    userId,
    title,
    message = null,
    meta = {},
    groupKey,
    status = "unread",
  } = payload;

  if (!userId || !groupKey || !type || !entityType || !entityId || !title) {
    return;
  }

  const [rows] = await conn.execute(
    "SELECT id FROM notifications WHERE user_id = ? AND group_key = ? LIMIT 1",
    [String(userId), groupKey],
  );

  if (rows.length > 0) {
    await conn.execute(
      `
        UPDATE notifications
        SET title = ?, message = ?, meta_json = ?, status = ?, read_at = NULL, updated_at = NOW()
        WHERE id = ?
      `,
      [title, message, JSON.stringify(meta || {}), status, rows[0].id],
    );
    return;
  }

  await conn.execute(
    `
      INSERT INTO notifications
      (id, type, category, entity_type, entity_id, parent_entity_type, parent_entity_id, user_id, title, message, meta_json, group_key, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    `,
    [
      crypto.randomUUID(),
      type,
      category,
      entityType,
      String(entityId),
      parentEntityType,
      parentEntityId ? String(parentEntityId) : null,
      String(userId),
      title,
      message,
      JSON.stringify(meta || {}),
      groupKey,
      status,
    ],
  );
}

async function resolveDealsNotifications(conn, todayStr, expiringSoonDateStr) {
  await conn.execute(
    `
      UPDATE notifications n
      LEFT JOIN deal_tasks dt
        ON n.entity_type = 'deal_task'
       AND n.entity_id = dt.id
      SET n.status = 'resolved', n.updated_at = NOW()
      WHERE n.category = 'deals'
        AND n.status = 'unread'
        AND n.type = 'deal_task_reminder'
        AND (
          dt.id IS NULL
          OR dt.status <> 'pending'
          OR DATE(dt.due_date) <= ?
        )
    `,
    [todayStr],
  );

  await conn.execute(
    `
      UPDATE notifications n
      LEFT JOIN deal_tasks dt
        ON n.entity_type = 'deal_task'
       AND n.entity_id = dt.id
      SET n.status = 'resolved', n.updated_at = NOW()
      WHERE n.category = 'deals'
        AND n.status = 'unread'
        AND n.type = 'deal_task_due_today'
        AND (
          dt.id IS NULL
          OR dt.status <> 'pending'
          OR DATE(dt.due_date) <> ?
        )
    `,
    [todayStr],
  );

  await conn.execute(
    `
      UPDATE notifications n
      LEFT JOIN deal_tasks dt
        ON n.entity_type = 'deal_task'
       AND n.entity_id = dt.id
      SET n.status = 'resolved', n.updated_at = NOW()
      WHERE n.category = 'deals'
        AND n.status = 'unread'
        AND n.type = 'deal_task_overdue'
        AND (
          dt.id IS NULL
          OR dt.status <> 'pending'
          OR DATE(dt.due_date) >= ?
        )
    `,
    [todayStr],
  );

  await conn.execute(
    `
      UPDATE notifications n
      LEFT JOIN deals d
        ON n.entity_type = 'deal'
       AND n.entity_id = d.id
      SET n.status = 'resolved', n.updated_at = NOW()
      WHERE n.category = 'deals'
        AND n.status = 'unread'
        AND n.type = 'deal_expiring_soon'
        AND (
          d.id IS NULL
          OR LOWER(COALESCE(d.status, '')) <> 'open'
          OR d.expected_close_date IS NULL
          OR DATE(d.expected_close_date) < ?
          OR DATE(d.expected_close_date) > ?
        )
    `,
    [todayStr, expiringSoonDateStr],
  );

  await conn.execute(
    `
      UPDATE notifications n
      LEFT JOIN deals d
        ON n.entity_type = 'deal'
       AND n.entity_id = d.id
      SET n.status = 'resolved', n.updated_at = NOW()
      WHERE n.category = 'deals'
        AND n.status = 'unread'
        AND n.type = 'deal_overdue'
        AND (
          d.id IS NULL
          OR LOWER(COALESCE(d.status, '')) <> 'open'
          OR d.expected_close_date IS NULL
          OR DATE(d.expected_close_date) >= ?
        )
    `,
    [todayStr],
  );
}

// ─────────────────────────────────────────────
// Document expiry notifications (customer_docs / supplier_docs)
//
// Unlike task reminders (discrete exact-day triggers), this is a continuous
// WINDOW: a document becomes notification-worthy the moment
// daysUntilExpiry <= max(configured doc_expiry_days), and keeps resurfacing
// every day (at most once/day) until it's renewed or removed — including
// already-expired documents, which should keep nagging until fixed.
//
// customer_docs/supplier_docs entries have no per-entry primary key, so the
// group_key uses doc.docId (stamped client-side on new uploads going
// forward) when present, falling back to a slug of docName (with a
// duplicate-name tiebreak) for older entries that predate docId.
// ─────────────────────────────────────────────

const DEFAULT_DOC_EXPIRY_WINDOW_DAYS = 30;

async function processDocumentExpiryNotifications() {
  let masterConnection;
  try {
    masterConnection = await masterPool.getConnection();
    const [clients] = await masterConnection.execute(
      "SELECT * FROM clients WHERE status = 'active'",
    );
    masterConnection.release();
    masterConnection = null;

    const todayStr = getLocalIsoString(new Date()).slice(0, 10);
    const today = new Date(todayStr);

    await Promise.allSettled(
      clients.filter(shouldProcessClient).map(async (client) => {
        let conn;
        try {
          const cfg = getClientDbConfig(client);
          conn = await getClientPool(cfg).getConnection();

          const [nsRows] = await conn
            .execute(
              "SELECT doc_expiry_enabled, doc_expiry_days FROM notification_settings ORDER BY id DESC LIMIT 1",
            )
            .catch(() => [[]]);

          const enabled = nsRows?.[0]
            ? Number(nsRows[0].doc_expiry_enabled) !== 0
            : true;
          const configuredDays = parseJsonArraySafe(nsRows?.[0]?.doc_expiry_days)
            .map(Number)
            .filter(Number.isFinite);
          const windowDays = configuredDays.length
            ? Math.max(...configuredDays)
            : DEFAULT_DOC_EXPIRY_WINDOW_DAYS;

          // Every group_key still within the window this run — the resolver
          // uses this to clear anything that's fallen out of it (renewed,
          // removed, or the feature just got disabled).
          const validGroupKeys = new Set();

          if (enabled) {
            const entityConfigs = [
              { table: "customer", docsCol: "customer_docs", idCol: "customer_id", entityType: "customer_doc", notifType: "customer_doc_expiring" },
              { table: "supplier", docsCol: "supplier_docs", idCol: "supplier_id", entityType: "supplier_doc", notifType: "supplier_doc_expiring" },
            ];

            for (const { table, docsCol, idCol, entityType, notifType } of entityConfigs) {
              const [rows] = await conn.execute(
                `SELECT ${idCol} AS id, name, ${docsCol} AS docs, assigned_to, created_by
                 FROM \`${table}\` WHERE ${docsCol} IS NOT NULL`,
              );

              for (const row of rows) {
                const docs = parseJsonArraySafe(row.docs);
                if (!docs.length) continue;

                const ownerUserId = getRecordOwnerUserId(row);
                if (!ownerUserId) continue;

                const seenSlugs = new Map(); // dedup counter for same-name docs on this record

                for (const doc of docs) {
                  if (!doc?.docExpiryDate) continue;
                  const expiry = new Date(doc.docExpiryDate);
                  if (isNaN(expiry.getTime())) continue;
                  expiry.setHours(0, 0, 0, 0);

                  const daysUntilExpiry = Math.round(
                    (expiry.getTime() - today.getTime()) / 86400000,
                  );
                  if (daysUntilExpiry > windowDays) continue;

                  const baseSlug = slugifyDocName(doc.docName);
                  const dupIndex = seenSlugs.get(baseSlug) || 0;
                  seenSlugs.set(baseSlug, dupIndex + 1);
                  const slugKey = dupIndex > 0 ? `${baseSlug}-${dupIndex}` : baseSlug;

                  const groupKey = `docexpiry:${entityType}:${row.id}:${doc.docId || slugKey}`;
                  validGroupKeys.add(groupKey);

                  // Dedup — at most one upsert per calendar day per document,
                  // mirroring last_notified_at's guarantee for tasks, but
                  // there's no per-doc-entry timestamp column to gate on, so
                  // check the notification row's own updated_at instead.
                  const [existing] = await conn.execute(
                    "SELECT id, DATE(updated_at) AS updated_date FROM notifications WHERE user_id = ? AND group_key = ? LIMIT 1",
                    [String(ownerUserId), groupKey],
                  );
                  if (existing.length && existing[0].updated_date === todayStr) continue;

                  const isExpired = daysUntilExpiry < 0;
                  const docLabel = doc.docName || "Document";
                  const entityName = row.name || (table === "customer" ? "customer" : "supplier");

                  await upsertNotification(conn, {
                    type: notifType,
                    category: "documents",
                    entityType,
                    entityId: row.id,
                    userId: ownerUserId,
                    title: isExpired ? "Document expired" : "Document expiring soon",
                    message: isExpired
                      ? `${docLabel} for ${entityName} expired ${Math.abs(daysUntilExpiry)} day(s) ago`
                      : `${docLabel} for ${entityName} expires in ${daysUntilExpiry} day(s)`,
                    meta: {
                      docName: doc.docName || "",
                      docExpiryDate: doc.docExpiryDate,
                      daysUntilExpiry,
                      uploadedPath: doc.uploadedPath || "",
                      entityName,
                      href: `/${table}/view/${row.id}`,
                    },
                    groupKey,
                  });
                }
              }
            }
          }

          await resolveDocumentExpiryNotifications(conn, validGroupKeys);
        } catch (err) {
          console.error(
            `[DocExpiry] Error processing client ${client.subdomain}:`,
            err.message,
          );
        } finally {
          if (conn) conn.release();
        }
      }),
    );
  } catch (err) {
    console.error("[DocExpiry] processDocumentExpiryNotifications error:", err.message);
  } finally {
    if (masterConnection) masterConnection.release();
  }
}

async function resolveDocumentExpiryNotifications(conn, validGroupKeys) {
  const [rows] = await conn.execute(
    `SELECT id, group_key FROM notifications
     WHERE type IN ('customer_doc_expiring', 'supplier_doc_expiring')
       AND status IN ('unread', 'read')`,
  );

  const staleIds = rows
    .filter((r) => !validGroupKeys.has(r.group_key))
    .map((r) => r.id);

  if (!staleIds.length) return;

  const placeholders = staleIds.map(() => "?").join(",");
  await conn.execute(
    `UPDATE notifications SET status = 'resolved', updated_at = NOW() WHERE id IN (${placeholders})`,
    staleIds,
  );
}

/**
 * FIX #11 – Sanitize user-supplied strings before embedding in HTML templates
 * to prevent XSS injection via customer_name, invoice_number, etc.
 */
function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * FIX #6 – Validate that a timezone string is a recognised IANA timezone.
 * Falls back to "UTC" and logs a warning when invalid.
 */
function resolveTimezone(tz) {
  const candidate = String(tz || "").trim();
  if (!candidate) return "UTC";
  try {
    // Intl.DateTimeFormat throws a RangeError for unknown timezones
    Intl.DateTimeFormat(undefined, { timeZone: candidate });
    return candidate;
  } catch {
    console.warn(
      `Invalid timezone "${candidate}" in master_settings – falling back to UTC`,
    );
    return "UTC";
  }
}
function shouldProcessClient(client) {
  if (!client || !client.subdomain) return false;

  const status = String(client.status || "")
    .trim()
    .toLowerCase();
  if (status && status !== "active") return false;

  if (
    Object.prototype.hasOwnProperty.call(client, "is_onboarded") &&
    client.is_onboarded != null &&
    !isTruthy(client.is_onboarded)
  ) {
    return false;
  }

  return true;
}

// ─────────────────────────────────────────────
// DB config / pool helpers
// ─────────────────────────────────────────────

function getClientDbConfig(client) {
  const subdomain = sanitizeSubdomain(client.subdomain);
  if (!subdomain) {
    throw new Error(
      "Cannot resolve client DB config without a valid subdomain",
    );
  }

  const defaultPrefix =
    process.env.TENANT_DB_NAME_PREFIX || DEFAULT_CLIENT_DB_PREFIX;

  return {
    host: client.tenant_db_host || requiredEnv("TENANT_DB_HOST"),
    port: toPositiveInt(
      client.tenant_db_port || process.env.TENANT_DB_PORT,
      3306,
    ),
    user: client.tenant_db_user || requiredEnv("TENANT_DB_USER"),
    password: client.tenant_db_password || requiredEnv("TENANT_DB_PASSWORD"),
    database:
      client.tenant_db_name ||
      `${defaultPrefix}${subdomain.replace(/[^a-z0-9]/g, "")}`,
  };
}

function getClientPoolKey(config) {
  return [config.host, config.port, config.user, config.database].join(":");
}

function getClientPool(config) {
  const key = getClientPoolKey(config);
  if (clientPools.has(key)) return clientPools.get(key);

  const pool = mysql.createPool({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    waitForConnections: true,
    connectionLimit: 4,
    queueLimit: 0,
    enableKeepAlive: true,
    dateStrings: true,
  });

  clientPools.set(key, pool);
  return pool;
}

const masterPool = mysql.createPool({
  host: requiredEnv("SAAS_DB_HOST"),
  port: toPositiveInt(process.env.SAAS_DB_PORT, 3306),
  user: requiredEnv("SAAS_DB_USER"),
  password: requiredEnv("SAAS_DB_PASSWORD"),
  database: requiredEnv("SAAS_DB_NAME"),
  waitForConnections: true,
  connectionLimit: 4,
  queueLimit: 0,
  enableKeepAlive: true,
  dateStrings: true,
});

function getClientBaseUrl(subdomain) {
  const cleanSubdomain = sanitizeSubdomain(subdomain);
  if (!cleanSubdomain) {
    throw new Error("Cannot build client URL without a valid subdomain");
  }

  const template = String(process.env.TENANT_APP_URL_TEMPLATE || "").trim();
  if (template) {
    if (!template.includes("{{subdomain}}")) {
      throw new Error(
        "TENANT_APP_URL_TEMPLATE must contain {{subdomain}} placeholder",
      );
    }
    const resolved = template.replace(/\{\{subdomain\}\}/g, cleanSubdomain);
    if (!/^https?:\/\//i.test(resolved)) {
      throw new Error(
        "TENANT_APP_URL_TEMPLATE must resolve to an absolute http/https URL",
      );
    }
    return resolved.replace(/\/+$/, "");
  }

  const protocol = String(process.env.TENANT_APP_PROTOCOL || "https").trim();
  const rootDomain = String(process.env.TENANT_APP_ROOT_DOMAIN || "").trim();

  if (!rootDomain) {
    throw new Error(
      "Set TENANT_APP_URL_TEMPLATE or TENANT_APP_ROOT_DOMAIN for client URLs",
    );
  }
  if (!/^[a-z]+$/i.test(protocol)) {
    throw new Error("TENANT_APP_PROTOCOL must be a valid URL protocol");
  }

  return `${protocol}://${cleanSubdomain}.${rootDomain}`.replace(/\/+$/, "");
}

// ─────────────────────────────────────────────
// Master DB – table / settings / log helpers
// ─────────────────────────────────────────────

async function ensureMasterTables() {
  // No master-DB tables currently need bootstrapping here — kept as a hook
  // for future master-DB schema setup, called once per run from runJob's
  // predecessors.
}

async function getMasterSettingsMap(connection, keys = []) {
  if (!keys.length) {
    const [rows] = await connection.execute(
      "SELECT `key`, `value` FROM master_settings",
    );
    return rows.reduce((acc, row) => {
      acc[row.key] = row.value;
      return acc;
    }, {});
  }

  const placeholders = keys.map(() => "?").join(", ");
  const [rows] = await connection.execute(
    `SELECT \`key\`, \`value\` FROM master_settings WHERE \`key\` IN (${placeholders})`,
    keys,
  );
  return rows.reduce((acc, row) => {
    acc[row.key] = row.value;
    return acc;
  }, {});
}

// ─────────────────────────────────────────────
// Tenant DB – settings helpers
// ─────────────────────────────────────────────

/**
 * FIX #5 – Return a safe default instead of throwing when email_settings is
 * absent so that invoices can still be created even if sending is impossible.
 * The caller decides whether to bail on auto-send.
 */
async function getEmailSettings(connection) {
  // Only an enabled configuration should auto-send. Verification is an
  // optional, ad-hoc sanity check (the "Verify" button) — not a precondition
  // for sending, so it is deliberately not part of this filter.
  const [rows] = await connection.execute(
    "SELECT * FROM email_settings WHERE active = 1 LIMIT 1",
  );
  const settings = rows?.[0];

  if (!settings) {
    console.warn(
      "No active email_settings row found – auto-send will be disabled for this tenant",
    );
    // Return a sentinel so callers know mail is not configured
    return null;
  }

  return settings;
}

async function getBrandSettings(connection) {
  const [rows] = await connection.execute(
    "SELECT * FROM brand_settings LIMIT 1",
  );
  const settings = rows?.[0] || {};
  settings.global_tax = normalizeMaybeJson(settings.global_tax, []);
  return settings;
}

// Standard STARTTLS-vs-implicit-TLS convention: secure only on port 465.
// Replaces the previous ad-hoc "encryption set && !=none && port!=587" rule
// (which incorrectly set secure:true on e.g. port 25) — mirrors the same
// reconciled heuristic used by the Next.js side's sendTenantEmail.js.
function cronSmtpSecure(port) {
  return String(port) === "465";
}

/**
 * Provider-aware send for the cron daemon — mirrors src/app/lib/sendTenantEmail.js
 * (a separate Node process can't import from the Next.js app). Branches on
 * mailCfg.provider: smtp/maileroo use nodemailer with a fixed shared
 * from-identity; brevo uses its REST API via native fetch. There is never a
 * logged-in user in cron context, so Brevo always sends as
 * mailCfg.default_from_email.
 */
async function sendTenantEmailCron(mailCfg, { toEmail, subject, html, attachments = [], fromName, brand }) {
  const displayName = fromName || mailCfg.fromName || brand?.company_name || "SalesERP";

  if (mailCfg.provider === "brevo") {
    if (!mailCfg.default_from_email) {
      throw new Error("No Default From Email configured for Brevo");
    }

    const res = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "api-key": mailCfg.api_key,
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        sender: { email: mailCfg.default_from_email, name: displayName },
        to: [{ email: toEmail }],
        subject,
        htmlContent: html,
        attachment: attachments.map((a) => ({
          name: a.filename,
          content: Buffer.isBuffer(a.content)
            ? a.content.toString("base64")
            : Buffer.from(a.content || "").toString("base64"),
        })),
      }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body?.message || `Brevo API error (${res.status})`);
    }
    return;
  }

  // smtp / maileroo — Maileroo is SMTP-shaped, identical transport, the only
  // difference is the from-address is always the fixed account username
  // rather than a configurable fromEmail (enforced by the caller passing the
  // right value through `mailCfg.fromEmail`/`mailCfg.username` as today).
  const transporter = nodemailer.createTransport({
    host: mailCfg.host,
    port: Number(mailCfg.port) || 587,
    secure: cronSmtpSecure(mailCfg.port),
    auth: {
      user: mailCfg.username,
      pass: mailCfg.password,
    },
  });

  await transporter.sendMail({
    from: `"${displayName}" <${mailCfg.provider === "maileroo" ? mailCfg.username : (mailCfg.fromEmail || mailCfg.username)}>`,
    to: toEmail,
    subject,
    html,
    attachments,
  });
}

// ─────────────────────────────────────────────
// Unified Multi-Stage Task Reminders
// Covers both deal_tasks and lead_tasks.
//
// Reminder schedule (fires once per day max, via last_notified_at dedup):
//   +3 days before due  → in-app + email  ("Due in 3 days")
//   +1 day before due   → in-app + email  ("Due tomorrow")
//    0 (due today)      → in-app + email  ("Due today")
//   -1 day overdue      → in-app + email  ("Overdue - 1 day")
//   -2 days overdue     → in-app only     ("Overdue - 2 days")
//   -3 days overdue     → in-app only     ("Overdue - 3 days")
//   >3 days overdue     → set reminder_sent=1 (stop forever)
//
// reminder_sent semantics:
//   0 = actively reminding
//   1 = permanently stopped (>3 days overdue, or task completed/cancelled)
//
// last_notified_at deduplication: at most ONE reminder per calendar day
// per task, regardless of how often the cron fires.
// ─────────────────────────────────────────────

// Trigger days relative to due_date (DATEDIFF = due_date - today).
// The positive ("days before due") portion is now per-client configurable
// via notification_settings.task_reminder_days — these are only the
// fallback used when a tenant has no settings row yet. The always-on tail
// (due-today, 1/2/3-days-overdue) is never configurable, unchanged from the
// original design.
const DEFAULT_TASK_REMINDER_DAYS = [7, 1];
const OVERDUE_STOP_THRESHOLD = -3;               // stop after 3 days overdue

function getReminderLabel(daysUntilDue) {
  if (daysUntilDue === 1)  return { subject: "Due Tomorrow",   tag: "due_tomorrow",   color: "#f59e0b" };
  if (daysUntilDue === 0)  return { subject: "Due Today",      tag: "due_today",      color: "#ef4444" };
  if (daysUntilDue === -1) return { subject: "Overdue",        tag: "overdue",        color: "#dc2626" };
  if (daysUntilDue === -2) return { subject: "Overdue (2 days)", tag: "overdue",      color: "#dc2626" };
  if (daysUntilDue <= -3)  return { subject: "Overdue (3 days)", tag: "overdue",       color: "#dc2626" };
  // Any other positive "days before due" value — covers the configurable
  // set (e.g. 2, 7) that isn't one of the fixed 1/0/-1/-2/-3 stages above.
  return { subject: `Due in ${daysUntilDue} Days`, tag: `due_in_${daysUntilDue}_days`, color: "#6366f1" };
}

function getNotificationType(daysUntilDue) {
  if (daysUntilDue >= 1)  return "task_reminder";
  if (daysUntilDue === 0) return "task_due_today";
  return "task_overdue";
}

async function sendTaskReminderEmail({ emailSettings, brandSettings, task, daysUntilDue, recipientEmail, recipientName, taskContext, baseUrl }) {
  if (!emailSettings || !recipientEmail) return false;
  const { subject: stageLabel, color } = getReminderLabel(daysUntilDue);
  const dueDateFormatted = new Date(task.due_date).toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });
  const contextLine = taskContext.deal_name
    ? `Deal: <strong>${escapeHtml(taskContext.deal_name)}</strong>`
    : taskContext.lead_name
    ? `Lead: <strong>${escapeHtml(taskContext.lead_name)}</strong>`
    : "";

  const taskBody = `
    <table cellpadding="0" cellspacing="0" style="width:100%;font-size:14px;color:#4b5563;">
      <tr><td style="padding:8px 0;width:140px;"><strong>Task</strong></td><td style="padding:8px 0;">${escapeHtml(task.title)}</td></tr>
      ${contextLine ? `<tr><td style="padding:8px 0;"><strong>${taskContext.deal_name ? "Deal" : "Lead"}</strong></td><td style="padding:8px 0;">${contextLine}</td></tr>` : ""}
      <tr><td style="padding:8px 0;"><strong>Task Type</strong></td><td style="padding:8px 0;">${escapeHtml(task.task_type || "To Do")}</td></tr>
      <tr><td style="padding:8px 0;"><strong>Priority</strong></td><td style="padding:8px 0;">${escapeHtml(task.priority || "Normal")}</td></tr>
      <tr><td style="padding:8px 0;"><strong>Due Date</strong></td><td style="padding:8px 0;color:${color};font-weight:600;">${dueDateFormatted}${daysUntilDue < 0 ? " (Overdue)" : ""}</td></tr>
    </table>`;

  const html = TaskMailTemplate(
    taskBody, brandSettings,
    stageLabel.toUpperCase(),
    { user: { email_signature: "" } },
    baseUrl,
    { customerName: recipientName || "Team Member", userName: brandSettings.company_name || "Team" },
  );

  try {
    await sendTenantEmailCron(emailSettings, {
      toEmail: recipientEmail,
      subject: `${stageLabel}: ${escapeHtml(task.title)}`,
      html,
      brand: brandSettings,
    });
    return true;
  } catch (err) {
    console.warn(`[TaskReminder] Email failed for task ${task.id} → ${recipientEmail}:`, err.message);
    return false;
  }
}

async function processAllTaskReminders() {
  const summary = { sent: 0, skipped: 0, errors: 0 };
  let masterConnection;
  try {
    masterConnection = await masterPool.getConnection();
    const [clients] = await masterConnection.execute(
      "SELECT * FROM clients WHERE status = 'active'",
    );
    masterConnection.release();
    masterConnection = null;

    const todayStr = getLocalIsoString(new Date()).slice(0, 10);
    console.log(`[TaskReminder] Running for ${todayStr}`);

    await Promise.allSettled(
      clients.filter(shouldProcessClient).map(async (client) => {
        let conn;
        try {
          const cfg = getClientDbConfig(client);
          conn = await getClientPool(cfg).getConnection();

          // ── 0. Per-client configurable "days before due" ─────────────────────
          // Only the positive before-due offsets are configurable; the
          // always-on tail (due-today, 1/2/3-days-overdue) never changes.
          const [nsRows] = await conn.execute(
            "SELECT task_reminder_email_enabled, task_reminder_days FROM notification_settings ORDER BY id DESC LIMIT 1",
          ).catch(() => [[]]);
          const cfgDaysBefore = (
            parseJsonArraySafe(nsRows?.[0]?.task_reminder_days).length
              ? parseJsonArraySafe(nsRows?.[0]?.task_reminder_days)
              : DEFAULT_TASK_REMINDER_DAYS
          )
            .map(Number)
            .filter((d) => Number.isFinite(d) && d > 0);
          const emailEnabled = nsRows?.[0]?.task_reminder_email_enabled ?? 1;

          const reminderDays = new Set([...cfgDaysBefore, 0, -1, -2, -3]);
          const emailDays = new Set(
            Number(emailEnabled) === 0 ? [0, -1] : [...cfgDaysBefore, 0, -1],
          );
          const dayList = [...reminderDays];
          const inClause = dayList.map(() => "?").join(",");

          // ── 1. Stop reminders for tasks that have been overdue too long ──────
          // Uses the tenant-timezone-aware todayStr (not SQL CURDATE(), which
          // follows the DB server's own timezone) so this agrees with the
          // due-today/overdue classification computed below and in
          // processDealTasksReminders().
          await conn.execute(
            `UPDATE deal_tasks SET reminder_sent = 1
             WHERE status = 'pending' AND reminder_enabled = 1 AND reminder_sent = 0
               AND DATEDIFF(?, DATE(due_date)) > ?`,
            [todayStr, Math.abs(OVERDUE_STOP_THRESHOLD)],
          ).catch(() => {});

          await conn.execute(
            `UPDATE lead_tasks SET reminder_sent = 1
             WHERE status = 'pending' AND reminder_enabled = 1 AND reminder_sent = 0
               AND DATEDIFF(?, DATE(due_date)) > ?`,
            [todayStr, Math.abs(OVERDUE_STOP_THRESHOLD)],
          ).catch(() => {});

          // ── 2. Fetch eligible deal_tasks ─────────────────────────────────────
          const [dealTasks] = await conn.execute(
            `SELECT
               dt.id, dt.deal_id, dt.title, dt.due_date, dt.assigned_to,
               dt.priority, dt.task_type,
               DATEDIFF(DATE(dt.due_date), ?) AS days_until_due,
               d.deal_name,
               d.created_by AS deal_created_by,
               d.assigned_to AS deal_assigned_to,
               c.name AS customer_name
             FROM deal_tasks dt
             JOIN deals d ON d.id = dt.deal_id
             LEFT JOIN customer c ON c.customer_id = d.customer_id
             WHERE dt.status = 'pending'
               AND dt.reminder_enabled = 1
               AND dt.reminder_sent = 0
               AND (dt.last_notified_at IS NULL OR DATE(dt.last_notified_at) < ?)
               AND DATEDIFF(DATE(dt.due_date), ?) IN (${inClause})
             LIMIT 300`,
            [todayStr, todayStr, todayStr, ...dayList],
          );

          // ── 3. Fetch eligible lead_tasks ─────────────────────────────────────
          const [leadTasks] = await conn.execute(
            `SELECT
               lt.id, lt.lead_id, lt.title, lt.due_date, lt.created_by,
               lt.priority, lt.task_type,
               DATEDIFF(DATE(lt.due_date), ?) AS days_until_due,
               l.name AS lead_name,
               l.assigned_to AS lead_assigned_to
             FROM lead_tasks lt
             JOIN \`lead\` l ON l.lead_id = lt.lead_id
             WHERE lt.status = 'pending'
               AND lt.reminder_enabled = 1
               AND lt.reminder_sent = 0
               AND (lt.last_notified_at IS NULL OR DATE(lt.last_notified_at) < ?)
               AND DATEDIFF(DATE(lt.due_date), ?) IN (${inClause})
             LIMIT 300`,
            [todayStr, todayStr, todayStr, ...dayList],
          ).catch(() => [[]]);

          if (!dealTasks.length && !leadTasks.length) return;

          const emailSettings = await getEmailSettings(conn);
          const brandSettings = await getBrandSettings(conn);
          const baseUrl = getClientBaseUrl(client.subdomain);

          // Batch-fetch all recipient users to avoid N+1 queries
          const allRecipientIds = new Set();
          for (const t of dealTasks) {
            const ids = parseJsonArraySafe(t.assigned_to).map(Number).filter(Number.isFinite);
            const uid = ids[ids.length - 1] || Number(t.deal_created_by) || null;
            if (uid) allRecipientIds.add(uid);
          }
          for (const t of leadTasks) {
            const uid = Number(t.created_by) || null;
            if (uid) allRecipientIds.add(uid);
          }
          const userMap = new Map();
          if (allRecipientIds.size > 0) {
            const idList = [...allRecipientIds];
            const placeholders = idList.map(() => '?').join(',');
            const [userRows] = await conn.execute(
              `SELECT user_id, email, full_name FROM user WHERE user_id IN (${placeholders})`,
              idList,
            );
            for (const u of userRows) userMap.set(u.user_id, u);
          }

          // ── Helper: process one task ─────────────────────────────────────────
          const handleTask = async (task, kind /* "deal" | "lead" */) => {
            const days = Number(task.days_until_due);
            if (!reminderDays.has(days)) return;

            // Resolve recipient user ID
            let recipientUserId;
            if (kind === "deal") {
              const ids = parseJsonArraySafe(task.assigned_to).map(Number).filter(Number.isFinite);
              recipientUserId = ids[ids.length - 1] || Number(task.deal_created_by) || null;
            } else {
              recipientUserId = Number(task.created_by) || null;
            }
            if (!recipientUserId) return;

            // Look up recipient user from pre-fetched map
            const user = userMap.get(recipientUserId);
            if (!user) return;

            const notifType    = getNotificationType(days);
            const { tag }      = getReminderLabel(days);
            const sendEmail    = emailDays.has(days);
            const groupKey     = kind === "deal"
              ? `${tag}:deal-task:${task.id}:${todayStr}`
              : `${tag}:lead-task:${task.id}:${todayStr}`;

            const message = days >= 1
              ? `Task due in ${days} day${days > 1 ? "s" : ""}`
              : days === 0
              ? "Task is due today"
              : `Task overdue by ${Math.abs(days)} day${Math.abs(days) > 1 ? "s" : ""}`;

            // In-app notification
            await upsertNotification(conn, {
              type:             notifType,
              category:         kind === "deal" ? "deals" : "leads",
              entityType:       kind === "deal" ? "deal_task" : "lead_task",
              entityId:         task.id,
              parentEntityType: kind === "deal" ? "deal" : "lead",
              parentEntityId:   kind === "deal" ? task.deal_id : task.lead_id,
              userId:           recipientUserId,
              title:            task.title,
              message,
              meta: {
                kind:          tag,
                deal_id:       task.deal_id   || null,
                lead_id:       task.lead_id   || null,
                deal_name:     task.deal_name  || null,
                lead_name:     task.lead_name  || null,
                customer_name: task.customer_name || "",
                due_date:      task.due_date,
                priority:      task.priority  || "Normal",
                task_type:     task.task_type || "To Do",
                days_until_due: days,
                href: kind === "deal" ? `/deals/${task.deal_id}` : `/lead/view/${task.lead_id}`,
              },
              groupKey,
            });

            // Expo push notification
            await sendExpoPushNotifications(conn, recipientUserId, task.title, message, {
              type: notifType,
              entityType: kind === "deal" ? "deal_task" : "lead_task",
              entityId: String(task.id),
              href: kind === "deal" ? `/deals/${task.deal_id}` : `/lead/view/${task.lead_id}`,
            });

            // Email (only on selected stages)
            if (sendEmail) {
              await sendTaskReminderEmail({
                emailSettings, brandSettings,
                task, daysUntilDue: days,
                recipientEmail: user.email,
                recipientName:  user.full_name,
                taskContext: { deal_name: task.deal_name || null, lead_name: task.lead_name || null },
                baseUrl,
              });
            }

            // Stamp last_notified_at so this task won't fire again today
            const table = kind === "deal" ? "deal_tasks" : "lead_tasks";
            await conn.execute(
              `UPDATE ${table} SET last_notified_at = NOW() WHERE id = ?`,
              [task.id],
            );

            summary.sent++;
          };

          await Promise.allSettled(dealTasks.map((t) => handleTask(t, "deal")));
          await Promise.allSettled(leadTasks.map((t) => handleTask(t, "lead")));

        } catch (err) {
          summary.errors++;
          console.error(`[TaskReminder] Client ${client.subdomain} error:`, err.message);
        } finally {
          if (conn) conn.release();
        }
      }),
    );

    console.log(`[TaskReminder] Done — sent=${summary.sent} errors=${summary.errors}`);
    return summary;
  } catch (err) {
    console.error("[TaskReminder] Fatal error:", err.message);
    return summary;
  } finally {
    if (masterConnection) masterConnection.release();
  }
}

// ─────────────────────────────────────────────
// Main job
// ─────────────────────────────────────────────

async function runJob() {
  console.log(
    "\x1b[1m\x1b[35m-----------------------------------------\x1b[0m",
  );
  console.log(
    `\x1b[1m\x1b[35mCRON START (Ver 4.2): ${new Date().toLocaleString()}\x1b[0m`,
  );
  console.log(
    "\x1b[1m\x1b[35m-----------------------------------------\x1b[0m",
  );

  if (runtimeState.runInProgress) {
    console.warn("Previous scheduler run is still active; skipping");
    return;
  }
  runtimeState.runInProgress = true;

  try {
    // ── BACKGROUND JOB DISPATCH ───────────────────────────────────────────
    // Each job is fully isolated. Add new jobs here; never mix logic between them.
    // Run concurrently but await all of them so runInProgress stays true for
    // the full duration of the run — otherwise the overlap guard above is a no-op.
    await Promise.allSettled([
      // Job A: Resolve stale deal notifications + deal expiry alerts
      processDealTasksReminders().catch((err) =>
        console.error("[DealExpiry] Run failed:", err.message),
      ),

      // Job B: Multi-stage task reminders for both deal_tasks and lead_tasks
      //        (in-app notification + email, max once per day per task)
      processAllTaskReminders().catch((err) => {
        console.error("[TaskReminder] Run failed:", err.message);
      }),

      // Job C: Document expiry notifications (customer_docs / supplier_docs)
      processDocumentExpiryNotifications().catch((err) =>
        console.error("[DocExpiry] Run failed:", err.message),
      ),
    ]);
  } finally {
    runtimeState.runInProgress = false;
  }
}

// ─────────────────────────────────────────────
// Deal Task Reminders
// ─────────────────────────────────────────────

/**
 * Resolves stale deal-task notifications and fires deal expiry / overdue
 * notifications. Task reminders are handled by processAllTaskReminders().
 */
async function processDealTasksReminders() {
  let masterConnection;
  try {
    masterConnection = await masterPool.getConnection();
    const [clients] = await masterConnection.execute(
      "SELECT * FROM clients WHERE status = 'active'",
    );
    masterConnection.release();
    masterConnection = null;

    const localNowStr = getLocalIsoString(new Date());
    const todayStr = localNowStr.slice(0, 10);

    const expiringSoonDate = new Date(
      new Date(todayStr).getTime() + 7 * 86400000,
    );
    const expiringSoonDateStr = expiringSoonDate.toISOString().slice(0, 10);

    await Promise.allSettled(
      clients.filter(shouldProcessClient).map(async (client) => {
        let conn;
        try {
          const cfg = getClientDbConfig(client);
          const pool = getClientPool(cfg);
          conn = await pool.getConnection();

          await resolveDealsNotifications(conn, todayStr, expiringSoonDateStr);

          // Task reminders (email + in-app) handled by processAllTaskReminders()

          // Dedup gate — at most once per calendar day per deal (mirrors the
          // deal_tasks/lead_tasks last_notified_at pattern above). Without
          // this, the default every-minute cron schedule sent a real Expo
          // push and reset the in-app notification back to unread roughly
          // once a MINUTE, indefinitely, for every qualifying deal.
          const [deals] = await conn.execute(
            `SELECT d.id, d.deal_name, d.customer_id, c.name as customer_name, d.expected_close_date, d.status, d.created_by, d.assigned_to, d.priority
             FROM deals d
             LEFT JOIN customer c ON c.customer_id = d.customer_id
             WHERE LOWER(COALESCE(d.status, '')) = 'open'
               AND d.expected_close_date IS NOT NULL
               AND DATE(d.expected_close_date) <= ?
               AND (d.last_notified_at IS NULL OR DATE(d.last_notified_at) < ?)`,
            [expiringSoonDateStr, todayStr],
          );

          for (const deal of deals) {
            const ownerUserId = getDealOwnerUserId(deal);
            if (!ownerUserId) continue;

            const closeDateStr = new Date(deal.expected_close_date)
              .toISOString()
              .slice(0, 10);
            const isOverdue = closeDateStr < todayStr;

            await upsertNotification(conn, {
              type: isOverdue ? "deal_overdue" : "deal_expiring_soon",
              entityType: "deal",
              entityId: deal.id,
              userId: ownerUserId,
              title: deal.deal_name,
              message: isOverdue
                ? `Deal overdue for closing`
                : `Deal closing soon`,
              meta: {
                kind: isOverdue ? "deal_overdue" : "deal_expiring_soon",
                deal_id: deal.id,
                deal_name: deal.deal_name,
                customer_name: deal.customer_name || "",
                expected_close_date: deal.expected_close_date,
                priority: deal.priority || "Normal",
                href: `/deals/${deal.id}`,
              },
              groupKey: `${isOverdue ? "deal-overdue" : "deal-expiring-soon"}:${deal.id}:${isOverdue ? todayStr : closeDateStr}`,
            });

            await sendExpoPushNotifications(
              conn,
              ownerUserId,
              deal.deal_name,
              isOverdue ? "Deal overdue for closing" : "Deal closing soon",
              {
                type: isOverdue ? "deal_overdue" : "deal_expiring_soon",
                entityType: "deal",
                entityId: String(deal.id),
                href: `/deals/${deal.id}`,
              },
            );

            // Stamp last_notified_at so this deal won't fire again today
            await conn.execute(
              `UPDATE deals SET last_notified_at = NOW() WHERE id = ?`,
              [deal.id],
            );
          }
        } catch (err) {
          console.error(
            `[DealTasks] Error processing client ${client.subdomain}:`,
            err.message,
          );
        } finally {
          if (conn) conn.release();
        }
      }),
    );
  } catch (err) {
    console.error("[DealTasks] processDealTasksReminders error:", err.message);
  } finally {
    if (masterConnection) masterConnection.release();
  }
}

// ─────────────────────────────────────────────
// Scheduler bootstrap / refresh
// ─────────────────────────────────────────────

async function getSchedulerSettings(connection) {
  const settings = await getMasterSettingsMap(connection, [
    MASTER_SETTING_CRON_SCHEDULE,
    MASTER_SETTING_CRON_TIMEZONE,
    MASTER_SETTING_MAX_PARALLEL_CLIENTS,
  ]);

  // FIX #6 – Validate the timezone with resolveTimezone so bad values fall
  // back to UTC rather than crashing node-cron.
  return {
    schedule:
      String(settings[MASTER_SETTING_CRON_SCHEDULE] || "").trim() ||
      DEFAULT_CRON_SCHEDULE,
    timezone: resolveTimezone(settings[MASTER_SETTING_CRON_TIMEZONE]),
    maxParallelClients: toPositiveInt(
      settings[MASTER_SETTING_MAX_PARALLEL_CLIENTS],
      DEFAULT_MAX_PARALLEL_CLIENTS,
    ),
  };
}

async function refreshSchedule() {
  if (runtimeState.scheduleRefreshInFlight) return;
  runtimeState.scheduleRefreshInFlight = true;

  let connection;
  try {
    connection = await masterPool.getConnection();
    await ensureMasterTables();
    const settings = await getSchedulerSettings(connection);

    if (!cron.validate(settings.schedule)) {
      throw new Error(
        `Invalid ${MASTER_SETTING_CRON_SCHEDULE} value in master_settings: ${settings.schedule}`,
      );
    }

    if (
      runtimeState.activeSchedule === settings.schedule &&
      runtimeState.activeTimezone === settings.timezone
    ) {
      return; // nothing changed – no need to restart the cron task
    }

    if (runtimeState.activeCronTask) {
      runtimeState.activeCronTask.stop();
      runtimeState.activeCronTask = null;
    }

    runtimeState.activeCronTask = cron.schedule(settings.schedule, runJob, {
      timezone: settings.timezone,
    });
    runtimeState.activeSchedule = settings.schedule;
    runtimeState.activeTimezone = settings.timezone;

    console.log(
      `Cron Scheduler started on schedule "${settings.schedule}" ` +
        `(${settings.timezone})`,
    );
  } catch (error) {
    console.error("Failed to refresh cron schedule from master DB:", error);
  } finally {
    // scheduleRefreshInFlight is always reset, even on error – no risk of
    // permanently locking out future refreshes (original code was correct here).
    if (connection) connection.release();
    runtimeState.scheduleRefreshInFlight = false;
  }
}

async function startScheduler() {
  await refreshSchedule();
  setInterval(refreshSchedule, SCHEDULE_REFRESH_INTERVAL_MS);
}

startScheduler().catch((error) => {
  console.error("Failed to start cron scheduler:", error);
  process.exit(1);
});
